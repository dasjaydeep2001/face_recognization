package com.faceRecogntion.FaceRecognition;

public class TestRecog{
	private Thread myThread= null;
}